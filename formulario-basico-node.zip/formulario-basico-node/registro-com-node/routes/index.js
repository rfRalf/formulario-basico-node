debugger

var express = require('express');
var router = express.Router();
var pessoas = [];

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express', pessoas : pessoas});
});

/* add pessoa */
router.post("/cadastrar-pessoa", function(req, res, next) {

var nome = req.body.nome;
hash = {
  nome: req.body.nome,
  sobrenome: req.body.sobrenome,
  cpf: req.body.cpf,
  telefone: req.body.telefone,
  endereco: req.body.endereco,
}

  pessoas.push(hash);

  res.render("index", { title:"cadastrar-pessoa", pessoas : pessoas });
});

/* rm pessoa */
router.get('/remover-pessoa', function(req, res, next) {
  res.render('index', { title: 'remoção', pessoas : pessoas});

  pessoas.pop(hash);
});
module.exports = router;
